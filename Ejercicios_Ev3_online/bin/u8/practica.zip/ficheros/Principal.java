package u8.ficheros;

public class Principal {

	public static void main(String[] args) {
		Ejemplo.escribir("C:\\nuevo.txt");
		//Ejemplo.leer("C:\\nuevo.txt");
	}

}
